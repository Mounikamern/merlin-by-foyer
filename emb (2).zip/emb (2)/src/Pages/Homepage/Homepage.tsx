import { BarChart, ProgressViewer } from '../../Components';
import GridLayout, { Layout } from "react-grid-layout"
import { Bar, Line } from "react-chartjs-2";
import style from "./Homepage.module.scss"
import React, { ReactChildren } from "react";
import LineChart from "../../Components/LineChart/LineChart";
import SpeedOmeeter from "../../Components/SpeedOmeterChart/SpeedOmeter";
import Cards from "../../Components/Cards/Cards";
import { Responsive, WidthProvider } from "react-grid-layout";

const ResponsiveGridLayout = WidthProvider(Responsive);
function Homepage(){
  // registry of all the reusable components
  const elementList = [
    /* {
      name: 'barGraph',
      element: BarGraph,
    },
    {
      name: 'lineGraph',
      element: LineGraph,
    }, */
    {
      name: 'lineChart',
      element: LineChart,
    },
    {
      name: 'speedoMeter',
      element: SpeedOmeeter,
    },
    {
      name:'cards',
      element:Cards
    },
    {
      name:'progressViewer',
      element:ProgressViewer
    },
    {
      name:'barChart',
      element:BarChart
    }
   
];

  function returnElement(id: string): any {
    let element: any;
    let [type, iid] = id.split('-');
    for (let i = 0; i < elementList.length; i++) {
      if (elementList[i].name == type) {
        element = elementList[i].element;
      }
    }
    if (element) {
      console.log(true);
      return element;
    } else {
      console.log(false);
      return function () {
        return <></>;
      };
    }
  }

  function onLayoutChange(layout1:any) {
    console.log(layout1);
  }
  return (
    <div className="container-fluid main-box" >
      <div className="row">
        <div className="col-md-12">
          <div className="d-sm-flex align-items-center justify-content-between mb-2">
            <div className="welcome_text">
              <h1 className="user_name_heading h3">Hello Sunny Bharti </h1>
              <p className="welcome_subtext">
                Welcome back, Here is your account snapshot{' '}
              </p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Grid layout container  */}
      <div className={style.layoutContainer} >
        <ResponsiveGridLayout
          className='layout '
          layouts={layout}
          cols={{ lg: 10}}
          breakpoints={{ lg: 1200 }}
          rowHeight={30}
          width={1200}
          onLayoutChange={onLayoutChange}
          containerPadding={[10,10]}
          compactType={null}
        >
          {layout.lg.map((ele: any) => (
            <div data-grid={ele} className='' key={ele.i}>
              {React.createElement(returnElement(ele.i) ,ele.data )}
            </div>
          ))}
        </ResponsiveGridLayout>
      </div>
    </div>
  );
}

export default Homepage;

export const options = {
  responsive: true,
  plugins: {
    legend: {
      position: 'top' as const,
    },
    title: {
      display: true,
      text: 'Chart.js Bar Chart',
    },
  },
};

const labels = ['January', 'February', 'March', 'April', 'May', 'June'];

export const data = {
  labels,
  datasets: [
    {
      label: 'Dataset 1',
      data: [12, 19, 3, 5, 2, 3],
      backgroundColor: 'rgba(255, 99, 132, 0.5)',
    },
    {
      label: 'Dataset 2',
      data: [12, 19, 3, 5, 2, 3],
      backgroundColor: 'rgba(53, 162, 235, 0.5)',
    },
  ],
};

export function BarGraph(props:any) {

  return <Bar options={options} data={data} />
}
export function LineGraph() {
  return <Line options={options} data={data} />;
}

const progressViewer1Data = {
  header:'Total Amount',
  total: '$13,548,223',
  barData: [
    { name: 'Overdue',value: 45, color: '#DA4F54' },
    { name: 'Outstanding', value: 35, color: '#D3D31C' },
    { name: 'Paid', value: 20, color: '#19D057' },
  ],
};

let cardData1={
  title: "Upcoming",
  paragraph: "Next 7 days",
  amount: "$24135",
  dec: "20 Invoices & 4 Customers",
  sub_dec: "",
  box_style: "#d3e5f9",
  text_color: ""
};
let cardData2={
  title: "Total Collected Amount",
  paragraph: "",
  amount: "$252300",
  dec: "10 Invoices & 3 Customers",
  sub_dec: "20% From last month",
  box_style: "#D4E5DA",
  text_color: "text-[14px] text-green-600"
}
let cardData3 ={
  title: "Outstanding Amount",
  paragraph: "",
  amount: "$1215600",
  dec: "50 Invoices & 9 Customers",
  sub_dec: "5% From last month",
  box_style: "#f5f6e6",
  text_color: "text-[14px] text-red-600"
}
let cardData4 ={
  title: "Overdue Amount",
  paragraph: "",
  amount: "$5243560",
  dec: "30 Invoices & 7 Customers",
  sub_dec: "10% From last month",
  box_style: "#f5e5e8",
  text_color: "text-[14px] text-green-600"
}
let cardData5 ={
  title: "Unadjusted Credit",
  paragraph: "",
  amount: "$5243560",
  dec: "30 Invoices & 7 Customers",
  sub_dec: "20% From last month",
  box_style: "#def1f8",
  text_color: "text-[14px] text-green-600"
}

let barData1={
  data : {
  labels:["Total Due", "0-30 days", "31-60 days", "61-90 days", "90-120 days", "120-180 days", "180+ days"],
  datasets: [
    {
      data: [5, 8, 4, 6, 5, 6, 7, 8, 5, 6, 4, 3],
      backgroundColor: "rgba(144, 158, 204,1)",
      borderColor: "rgba(144, 158, 204,1)",
      borderWidth: 1,
      barThickness: 54,
    },
    {
      data: [12, 19, 3, 5, 2, 3, 10, 15, 8, 5, 6, 4],
      backgroundColor: "rgb(144, 204, 194,1)",
      borderColor: "rgb(144, 204, 194,1)",
      borderWidth: 1,
      barThickness: 54,
    },
    {
      data: [7, 11, 5, 8, 3, 4, 8, 10, 6, 4, 7, 3],
      backgroundColor: "rgba(208, 233, 179, 1)",
      borderColor: "rgba(208, 233, 179, 1)",
      borderWidth: 1,
      barThickness: 54,
    },
  ],
},
options: {
  plugins: {
    legend: {
      display:false
    }
  },
  responsive: true,
  scales: {
    x: {
      stacked: true,
      grid: {
        display: false
      }
    },
    y: {
      stacked: true,
      grid: {
        display: false
      }
    },
  },
}
}

let speedoMeter1 = 
  {
    dataObj : {
    labels: ['0', '20', '40', '60', '80', '100'],
    datasets: [{
      label: 'Days',
      data: [30, 60, 90],
      backgroundColor: (context: { chart: any; }) => {
        const chart = context.chart
        const { ctx, chartArea } = chart;
        if (!chartArea) return null
        const gradient = ctx.createLinearGradient(chartArea.left, chartArea.top, chartArea.right, chartArea.bottom)
        gradient.addColorStop(0, '#09AE61');
        gradient.addColorStop(1, '#DA4F54');
        return gradient
      },
      borderColor: (context: any) => {
        const chart = context.chart
        const { ctx, chartArea } = chart;
        if (!chartArea) return null
        const gradient = ctx.createLinearGradient(chartArea.left, chartArea.top, chartArea.right, chartArea.bottom)
        gradient.addColorStop(0, '#09AE61');
        gradient.addColorStop(1, '#DA4F54');
        return gradient
      },
      borderWidth: 2,
      circumference: 180,
      rotation: 270,
      cutout: '70%',
      needleValue: 100,
    }],
  },
 options: {
    responsive: true,
    maintainAspectRatio: false,
    layout: {
      padding: {
        bottom: 20,
        top: 20
      },
    },
    aspectRatio: 2.4,
    plugins: {
      legend: {
        display: false,
        position: 'top',
      },
      tooltip: {
        enabled: true,
        cornerRadius: 5,
      },
      datalabels: {
        color: function (context: any) {
          var index = context.dataIndex;
          var value: any = context.dataset.data[index];
          return value === Math.max(...[30, 60, 90]) ? 'white' : 'black'
        },
        align: 'end',
        offset: function (context: any) {
          var index = context.dataIndex;
          var value: any = context.dataset.data[index];
          return value === Math.max(...[30, 60, 90]) ? 2 : 25
        },
        display: function (context: any) {
          var dataset = context.dataset;
          var count = dataset.data.length;
          var value: any = dataset.data[context.dataIndex];
          return value > count * 1.5;
        },
        font: {
          weight: 'bold'
        },
        borderRadius: function (context: any) {
          var index = context.dataIndex;
          var value: any = context.dataset.data[index];
          return value === Math.max(...[30, 60, 90]) ? 50 : 0
        },
        padding: function (context: any) {
          var index = context.dataIndex;
          var value: any = context.dataset.data[index];
          return value === Math.max(...[30, 60, 90]) ? 10 : 0
        },
        backgroundColor: function (context: any) {
          var index = context.dataIndex;
          var value: any = context.dataset.data[index];
          return value === Math.max(...[30, 60, 90]) ? '#808080' : ''
        },
        formatter: function (value: any) {
          return value === Math.max(...[30, 60, 90]) ? '  ' + value + `\n` + 'Days' : value
        }
      }
    },
  }
}
 //object which will tell us which components need to add
 const layout = {lg:([
  { i: 'barChart-1', x: 0, y: 7, w: 7, h: 15,data:barData1},
  { i: 'speedoMeter-2', x: 7, y: 7, w: 3, h: 7 ,data:speedoMeter1},
  { i: 'cards-1', x: 0, y: 2, w: 2, h: 5 , data:cardData1},
  { i: 'cards-2', x: 2, y: 2, w: 2, h: 5 , data:cardData2},
  { i: 'cards-3', x: 4, y: 2, w: 2, h: 5 , data:cardData3},
  { i: 'cards-4', x: 6, y: 2, w: 2, h: 5 , data:cardData4},
  { i: 'cards-5', x: 8, y: 2, w: 2, h: 5 , data:cardData5},
  { i:'progressViewer-1',x:0,y:0,w:10,h:2,data:progressViewer1Data}
])};