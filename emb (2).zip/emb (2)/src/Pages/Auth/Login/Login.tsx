import Auth from '../Auth';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import { Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import checkFillLogo from '../../../Assests/img/check_fill.svg';
import { InputAdornment } from '@mui/material';
import './Login.scss';
import { postRequests } from '../../../Services/api.sevice';
import { toast } from 'react-toastify';
import { Endpoint } from '../../../Utils/endpoints';

function Login() {
  const navigate = useNavigate();
  const [input, setInput]: any = useState({
    username: '',
    password: '',
  });

  const [error, setError]: any = useState({
    username: '',
    password: '',
  });

  const onInputChange = (e: any) => {
    const { name, value } = e.target;
    setInput((prev: any) => ({
      ...prev,
      [name]: value,
    }));
    validateInput(e);
  };

  const validateInput = (e: any) => {
    let { name, value } = e.target;
    setError((prev: any) => {
      const stateObj: any = { ...prev, [name]: '' };
      switch (name) {
        case 'username':
          if (!value) {
            stateObj[name] = 'Please enter Email.';
          } else if (
            !/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@(([[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(
              value
            )
          ) {
            stateObj[name] = 'Email is invalid';
          }
          break;

        case 'password':
          if (!value) {
            stateObj[name] = 'Please enter Password.';
          }
          break;
        default:
          break;
      }
      return stateObj;
    });
  };

  function handleSubmit (e: any) {
    e.preventDefault();
    // Validation
    const newErrors = { username: '', password: '' };
    let valid = false;
    if (!input.username) {
      newErrors.username = 'Please enter Email.';
      valid = false;
    } else if (
      !/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@(([[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(
        input.username
      )
    ) {
      newErrors.username = 'Email is invalid';
      valid = false;
    } else {
      newErrors.username = '';
      valid = true;
    }

    if (!input.password) {
      newErrors.password = 'Please enter Password.';
      valid = false;
    } else {
      newErrors.password = '';
      valid = true;
    }
    if((!input.username && input.password) || (input.username && !input.password)) {
      valid = false;
    }
    if (!valid) {
      setError(newErrors);
    } else {
      postRequests(Endpoint.login, { data: input }).then((res: any) => {
        setInput({ username: '', password: '' });
        setError({ username: '', password: '' });
        if (res.success) {
          toast.success(res.message, {
            theme: "colored"
          });
          localStorage.setItem('account_id', res.data.id);
          navigate('/main/home');
        } else {
          e.target.reset();
          toast.error(res.message, {
            theme: "colored"
          })
        }
      }).catch(() => {})
    }
  };

  return (
    <>
      <div className="log-in-screen">
        <div className="row gradient-bg align-items-center">
          <div className="col logInField">
            <div className="fieldInner">
              <div className="embeeLogo"></div>
              <h2>Sign in to your dashboard</h2>
              <p>Enter your email address and password to continue</p>
              <form onSubmit={handleSubmit}>
                <TextField
                  fullWidth
                  name="username"
                  type="email"
                  size="medium"
                  placeholder="shekhar@embee.co.in"
                  value={input.email}
                  onChange={onInputChange}
                  onBlur={validateInput}
                  error={error && !!error.username}
                  helperText={error && error.username}
                  margin="normal"
                  inputProps={{ className: 'loginField' }}
                  InputProps={{
                    endAdornment:
                      error.username !== '' || input.username === '' ? (
                        ''
                      ) : (
                        <InputAdornment position="end">
                          <img src={checkFillLogo} alt="no-img" />
                        </InputAdornment>
                      ),
                  }}
                />
                <TextField
                  fullWidth
                  name="password"
                  type="password"
                  placeholder="Password"
                  size="medium"
                  value={input.password}
                  onChange={onInputChange}
                  onBlur={validateInput}
                  error={error && !!error.password}
                  helperText={error && error.password}
                  margin="normal"
                  inputProps={{ className: 'loginField' }}
                  InputProps={{
                    endAdornment:
                      error.password !== '' || input.password === '' ? (
                        ''
                      ) : (
                        <InputAdornment position="end">
                          <img src={checkFillLogo} alt="no-img" />
                        </InputAdornment>
                      ),
                  }}
                />
                <Button
                  variant="contained"
                  color="primary"
                  type="submit"
                  className="submitBtn"
                >
                  Sign In
                </Button>
                <div>
                  {/* <span
                    className="forgot-password"
                    style={{ display: 'inline', float: 'left' }}
                  >
                    <Link className="nav-link" to="/signup">
                      New User?
                    </Link>
                  </span> */}
                  <span
                    className="forgot-password"
                    style={{ display: 'inline', float: 'right' }}
                  >
                    <Link className="nav-link" to="/forgot-password">
                      Forgot Password?
                    </Link>
                  </span>
                </div>
              </form>
            </div>
          </div>
          <Auth />
        </div>
      </div>
    </>
  );
}

export default Login;
