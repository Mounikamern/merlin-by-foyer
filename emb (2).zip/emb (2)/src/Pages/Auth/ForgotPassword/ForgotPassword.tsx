import React, { useState } from 'react';
import Auth from '../Auth';
import { Link } from 'react-router-dom';
import { Button, InputAdornment, TextField } from '@mui/material';
import checkFillLogo from '../../../Assests/img/check_fill.svg';
import { toast } from 'react-toastify';
import { postRequests } from '../../../Services/api.sevice';
import { Endpoint } from '../../../Utils/endpoints';

export default function ForgotPassword() {
  const [input, setInput]: any = useState({
    email: '',
  });

  const [error, setError]: any = useState({
    email: '',
  });

  const onInputChange = (e: any) => {
    const { name, value } = e.target;
    setInput((prev: any) => ({
      ...prev,
      [name]: value,
    }));
    validateInput(e);
  };

  const validateInput = (e: any) => {
    let { name, value } = e.target;
    setError((prev: any) => {
      const stateObj: any = { ...prev, [name]: '' };
      switch (name) {
        case 'email':
          if (!value) {
            stateObj[name] = 'Please enter Email.';
          } else if (
            !/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@(([[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(
              value
            )
          ) {
            stateObj[name] = 'Email is invalid';
          }
          break;

        default:
          break;
      }
      return stateObj;
    });
  };

  const handleSubmit = (e: any) => {
    e.preventDefault();
    // Validation
    const newErrors = { email: '', password: '' };
    let valid = false;
    if (!input.email) {
      newErrors.email = 'Please enter Email.';
      valid = false;
    } else if (
      !/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@(([[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(
        input.email
      )
    ) {
      newErrors.email = 'Email is invalid';
      valid = false;
    } else {
      newErrors.email = '';
      valid = true;
    }

    if (!valid) {
      setError(newErrors);
    } else {
      postRequests(Endpoint.forgotPassword, { data: input }).then((res: any) => {
        setInput({ email: '' });
        setError({ email: '' });
        if (res.success) {
          toast.success('Reset password link has been successfully sent to your registered email.', {
            theme: "colored"
          })
        } else {
          toast.error(res.message, {
            theme: "colored"
          })
        }
      }).catch((e: any) => {
        console.log(e);
      })
    }
  };
  return (
    <React.Fragment>
      <div className="log-in-screen">
        <div className="row gradient-bg align-items-center">
          <div className="col logInField">
            <div className="fieldInner">
              <div className="embeeLogo"></div>
              <h2>Forgot your password</h2>
              <p>Enter your email address and continue</p>
              <form onSubmit={handleSubmit}>
                <TextField
                  fullWidth
                  name="email"
                  type="email"
                  size="medium"
                  placeholder="shekhar@embee.co.in"
                  value={input.email}
                  onChange={onInputChange}
                  onBlur={validateInput}
                  error={error && !!error.email}
                  helperText={error && error.email}
                  margin="normal"
                  inputProps={{ className: 'loginField' }}
                  InputProps={{
                    endAdornment:
                      error.email !== '' || input.email === '' ? (
                        ''
                      ) : (
                        <InputAdornment position="end">
                          <img src={checkFillLogo} alt="no-img" />
                        </InputAdornment>
                      ),
                  }}
                />
                <Button
                  variant="contained"
                  color="primary"
                  type="submit"
                  className="submitBtn"
                >
                  Submit
                </Button>
                <span className="forgot-password">
                  <Link to={'/login'}>Back To Login</Link>
                </span>
              </form>
            </div>
          </div>
          <Auth />
        </div>
      </div>
    </React.Fragment>
  );
}
