import { useState } from 'react';
import { Auth } from '../..';
import { useNavigate, useParams } from 'react-router-dom';
import { toast } from 'react-toastify';
import { InputAdornment } from '@mui/material';
import checkFillLogo from '../../../Assests/img/check_fill.svg';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import '../../../Services/api.sevice';
import { postRequests } from '../../../Services/api.sevice';
import { Endpoint } from '../../../Utils/endpoints';

function Signup() {
  const navigate = useNavigate();
  const params: any = useParams();
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    token: params.token
  });

  const [errors, setErrors] = useState({
    username: '',
    password: '',
  });

  const onInputChange = (e: any) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    validateInput(e);
  };

  const validateInput = (e: any) => {
    let { name, value } = e.target;
    setErrors((prev) => {
      const stateObj: any = { ...prev, [name]: '' };
      switch (name) {
        case 'username':
          if (!value) {
            stateObj[name] = 'Please enter Username';
          }
          break;

        case 'password':
          if (!value) {
            stateObj[name] = 'Please enter Password.';
          } else if (formData.password.length < 6) {
            stateObj[name] = 'Password must be at least 6 characters long';
          }
          break;
        default:
          break;
      }

      return stateObj;
    });
  };

  const handleSubmit = (e: any) => {
    e.preventDefault();
    const newErrors = { username: '', email: '', password: '' };
    let valid = false;

    if (!formData.username) {
      newErrors.username = 'Please enter Username';
      valid = false;
    } else {
      newErrors.email = '';
      valid = true;
    }

    if (!formData.password) {
      newErrors.password = 'Please enter Password.';
      valid = false;
    } else if (formData.password.length < 6) {
      newErrors.password = 'Password should have minimum 6 characters.';
      valid = false;
    } else {
      newErrors.password = '';
      valid = true;
    }
    if (
      (!formData.password)
    ) {
      valid = false;
    }
    if (
      (!formData.password && formData.username) ||
      (formData.password && !formData.username)
    ) {
      valid = false;
    }
    if (!valid) {
      setErrors(newErrors);
    } else {
      postRequests(Endpoint.signup, { data: formData })
        .then((res: any) => {
          setFormData({
            username: '',
            password: '',
            token: params.token
          });
          setErrors({
            username: '',
            password: '',
          });

          if (res.success) {
            toast.success(res.message, {
              theme: 'colored',
            });
            navigate('/login');
          } else {
            toast.error(res.message, {
              theme: 'colored',
            });
          }
        })
        .catch((e: any) => {
          console.log(e);
        });
    }
  };

  return (
    <div className="log-in-screen">
      <div className="row gradient-bg align-items-center">
        <div className="col logInField">
          <div className="fieldInner">
            <div className="embeeLogo"></div>
            <h2>Sign up to your dashboard</h2>
            <p>Enter your details to continue</p>
            <form onSubmit={handleSubmit}>
              <TextField
                fullWidth
                type="text"
                name="username"
                size="medium"
                placeholder="Username"
                value={formData.username}
                onChange={onInputChange}
                onBlur={validateInput}
                margin="normal"
                inputProps={{ className: 'loginField' }}
                InputProps={{
                  endAdornment:
                    errors.username !== '' || formData.username === '' ? (
                      ''
                    ) : (
                      <InputAdornment position="end">
                        <img src={checkFillLogo} alt="no-img" />
                      </InputAdornment>
                    ),
                }}
              />
              {errors.username && (
                <div className="error-message">{errors.username}</div>
              )}

              <TextField
                fullWidth
                type="password"
                name="password"
                placeholder="Password"
                size="medium"
                value={formData.password}
                onChange={onInputChange}
                onBlur={validateInput}
                margin="normal"
                inputProps={{ className: 'loginField' }}
                InputProps={{
                  endAdornment:
                    errors.password !== '' || formData.password === '' ? (
                      ''
                    ) : (
                      <InputAdornment position="end">
                        <img src={checkFillLogo} alt="no-img" />
                      </InputAdornment>
                    ),
                }}
              />
              {errors.password && (
                <div className="error-message">{errors.password}</div>
              )}
              <Button
                variant="contained"
                color="primary"
                type="submit"
                className="submitBtn"
              >
                Sign Up
              </Button>
            </form>
          </div>
        </div>
        <Auth />
      </div>
    </div>
  );
}

export default Signup;
