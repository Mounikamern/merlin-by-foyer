import React from 'react';
import Auth from '../Auth';
import { useNavigate } from 'react-router';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import { useState } from 'react';
import checkFillLogo from '../../../Assests/img/check_fill.svg';
import { InputAdornment } from '@mui/material';
import '../Login/Login.scss';
import { toast } from 'react-toastify';
import { postRequests } from '../../../Services/api.sevice';
import { Endpoint } from '../../../Utils/endpoints';
import { useParams } from 'react-router-dom';

export default function ResetPassword() {
  const navigate = useNavigate();
  const params: any = useParams();
  const [input, setInput]: any = useState({
    password: '',
    confirmPassword: '',
  });

  const [error, setError]: any = useState({
    password: '',
    confirmPassword: '',
  });

  const onInputChange = (e: any) => {
    const { name, value } = e.target;
    setInput((prev: any) => ({
      ...prev,
      [name]: value,
    }));
    validateInput(e);
  };

  const validateInput = (e: any) => {
    let { name, value } = e.target;
    setError((prev: any) => {
      const stateObj: any = { ...prev, [name]: '' };
      switch (name) {
        case 'password':
          if (!value) {
            stateObj[name] = 'Please enter Password.';
          } else if (input.password.length < 6) {
            stateObj['password'] = 'Password should have minimum 6 characters.';
          } else if (input.confirmPassword && value !== input.confirmPassword) {
            stateObj['confirmPassword'] =
              'Password and Confirm Password does not match.';
          } else {
            stateObj['confirmPassword'] = input.confirmPassword
              ? ''
              : error.confirmPassword;
            stateObj[name] = '';
          }
          break;
        case 'confirmPassword':
          if (!value) {
            stateObj[name] = 'Please enter Confirm Password.';
          } else if (input.password && value !== input.password) {
            stateObj[name] = 'Password and Confirm Password does not match.';
          } else if (input.confirmPassword.length < 6) {
            stateObj[name] =
              'Confirm Password should have minimum 6 characters.';
          } else {
            stateObj[name] = '';
          }
          break;
        default:
          break;
      }
      return stateObj;
    });
  };

  const handleSubmit = (e: any) => {
    e.preventDefault();
    // Validation
    const newErrors = { password: '', confirmPassword: '' };
    let valid = false;

    if (!input.password) {
      newErrors.password = 'Please enter Password.';
      valid = false;
    } else if (input.password.length < 6) {
      newErrors.password = 'Password should have minimum 6 characters.';
      valid = false;
    } else if (
      input.confirmPassword &&
      input.password !== input.confirmPassword
    ) {
      newErrors.confirmPassword =
        'Password and Confirm Password does not match.';
    } else {
      newErrors.confirmPassword = input.confirmPassword
        ? ''
        : error.confirmPassword;
      newErrors.password = '';
      valid = true;
    }

    if (!input.confirmPassword) {
      newErrors.confirmPassword = 'Please enter Confirm Password.';
    } else if (input.password && input.confirmPassword !== input.password) {
      newErrors.confirmPassword =
        'Password and Confirm Password does not match.';
    } else if (input.confirmPassword.length < 6) {
      newErrors.confirmPassword =
        'Confirm Password should have minimum 6 characters.';
      valid = false;
    } else {
      newErrors.confirmPassword = '';
      valid = true;
    }
    if (
      (!input.confirmPassword && input.password) ||
      (input.confirmPassword && !input.password)
    ) {
      valid = false;
    }
    if (!valid) {
      setError(newErrors);
    } else {
      let payload = {
        password: input.password,
        token: params.token,
      };
      postRequests(Endpoint.resetPassword, { data: payload })
        .then((res: any) => {
          setInput({ password: '', confirmPassword: '' });
          setError({ password: '', confirmPassword: '' });
          if (res.success === true) {
            toast.success('Password updated successfully', {
              theme: 'colored',
            });
            navigate('/login');
          } else {
            toast.error(res.message, {
              theme: 'colored',
            });
          }
        })
        .catch((e: any) => {
          console.log(e);
        });
    }
  };
  return (
    <React.Fragment>
      <div className="log-in-screen">
        <div className="row gradient-bg align-items-center">
          <div className="col logInField">
            <div className="fieldInner">
              <div className="embeeLogo"></div>
              <h2>Reset your password</h2>
              <p>Reset your password and continue to login</p>
              <form onSubmit={handleSubmit}>
                <TextField
                  fullWidth
                  name="password"
                  type="password"
                  size="medium"
                  placeholder="Password"
                  value={input.password}
                  onChange={onInputChange}
                  onBlur={validateInput}
                  error={error && !!error.password}
                  helperText={error && error.password}
                  margin="normal"
                  inputProps={{ className: 'loginField' }}
                  InputProps={{
                    endAdornment:
                      error.password !== '' || input.password === '' ? (
                        ''
                      ) : (
                        <InputAdornment position="end">
                          <img src={checkFillLogo} alt="no-img" />
                        </InputAdornment>
                      ),
                  }}
                />
                <TextField
                  fullWidth
                  name="confirmPassword"
                  type="password"
                  placeholder="Confirm Password"
                  size="medium"
                  value={input.confirmPassword}
                  onChange={onInputChange}
                  onBlur={validateInput}
                  error={error && !!error.confirmPassword}
                  helperText={error && error.confirmPassword}
                  margin="normal"
                  inputProps={{ className: 'loginField' }}
                  InputProps={{
                    endAdornment:
                      error.confirmPassword !== '' ||
                      input.confirmPassword === '' ? (
                        ''
                      ) : (
                        <InputAdornment position="end">
                          <img src={checkFillLogo} alt="no-img" />
                        </InputAdornment>
                      ),
                  }}
                />
                <Button
                  variant="contained"
                  color="primary"
                  type="submit"
                  className="submitBtn"
                >
                  Reset Password
                </Button>
              </form>
            </div>
          </div>
          <Auth />
        </div>
      </div>
    </React.Fragment>
  );
}
