export default function Auth() {
    return (
        <>
            <div className="col rightImage">
            <img src={require("../../Assests/img/login-img.png")} alt="no-img"/>
          </div>
        </>
    )
}