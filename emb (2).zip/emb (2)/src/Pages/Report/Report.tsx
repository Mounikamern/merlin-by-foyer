function Report(){
    return(
        <>
            <p>Report</p>
        </>
    )
}

export default Report;