function Companies(){
    return(
        <>
            <p>Companies data</p>
        </>
    )
}


export default Companies;