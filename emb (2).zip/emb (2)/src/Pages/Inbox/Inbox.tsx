function Inbox(){
    return (
        <>
            <p>Inbox</p>
        </>
    )
}

export default Inbox;