
import { Bar, Line } from "react-chartjs-2";
import styles from './Configuration.module.scss'; 
import React from "react";
import { ChartSelection } from "..";
function Configuration(){
    return(
        <>
        <header> Stepper component</header>
        <section className={styles.configSection}>
         <ChartSelection/>
        </section>
        <footer className="d-flex justify-content-around"> 
            <button>Previous</button>
            <button> Next </button>
        </footer>
        </>
    )
}

export default Configuration;






