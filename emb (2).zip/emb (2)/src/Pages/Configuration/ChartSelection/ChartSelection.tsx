import React from 'react'
import styles from "./ChartSelection.module.scss"
import { Bar, Line } from 'react-chartjs-2';

function ChartSelection() {
    const data = [
        {
        name:BarGraph
        },
        {
            name:LineGraph
        }
    ];
    
    return(
        <div className='d-flex'>
        <div className={styles.chartList}>
            {data.map((ele:any,i:number) =>(
                <div> 
                    {React.createElement(ele.name)} 
                <button className="btn">Edit</button>
                </div>
            )) }
        </div> 
        <div>
            <ul>
                <li>Bar</li>
                <li>Pie</li>
                <li>speedoMeter</li>
                <li>card</li>
                
            </ul>
        </div>
        </div>
    )
}

export const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: true,
        text: 'Chart.js Bar Chart',
      },
    },
  };
  
  const labels = ['January', 'February', 'March', 'April', 'May', 'June'];
  
  export const data = {
    labels,
    datasets: [
      {
        label: 'Dataset 1',
        data: [12, 19, 3, 5, 2, 3],
        backgroundColor: 'rgba(255, 99, 132, 0.5)',
      },
      {
        label: 'Dataset 2',
        data: [12, 19, 3, 5, 2, 3],
        backgroundColor: 'rgba(53, 162, 235, 0.5)',
      },
    ],
  };
  
  export function BarGraph() {
    return <Bar options={options} data={data}  />;
  }
  export function LineGraph() {
    return <Line options={options} data={data}  />;
  }


export default ChartSelection;