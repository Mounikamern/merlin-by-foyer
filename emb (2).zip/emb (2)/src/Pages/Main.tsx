import { Outlet } from "react-router-dom"
import { SideNav, Header } from "../Components";
import classes from "./Main.module.scss";
function Main(){
    return(
        
        <> 
        <div id="wrapper">
        <SideNav/>
        <div id="content-wrapper" className={`d-flex flex-column ${classes.homeWrapper}`}>
            <div id="content">
                <Header/>
                <Outlet/>
            </div>
        </div>
        </div>
        </>
    )
}

export default Main