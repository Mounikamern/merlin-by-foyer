import classes from 'TrackingDashboard.module.scss';

function TrackingDashboard(){
    return(
        <>
            <p>Tracking DashBoard</p>
        </>
    )
}

export default TrackingDashboard;