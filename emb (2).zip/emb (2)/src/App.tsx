import React from 'react';
import logo from './logo.svg';
import './App.scss';
import { Outlet, RouterProvider, createBrowserRouter } from 'react-router-dom';
import { config } from './routes';




function App() {
  return (
    <><Outlet/></>
  );
}

export default App;
