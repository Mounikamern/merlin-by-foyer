import React from 'react';
import { Chart as ChartJS, LineElement } from 'chart.js/auto';
import { Line } from 'react-chartjs-2';
import { Box, Grid } from '@mui/material';
import { options } from '../../Pages/Homepage/Homepage';
import styles from './LineChart.module.scss'

const LineChart = () => {
  ChartJS.register(LineElement);
 
     const   data={
          labels: [
            'Total Due',
            '0-30 days',
            '31-60 days',
            '61-90 days',
            '90-120 days',
            '120-180 days',
            '180+ days',
          ],
          datasets: [
            {
              label: '0-30 days',
              data: [12, 19, 3, 5, 2, 3, 10, 15, 8, 5, 6, 4],
              backgroundColor: 'rgba(144, 158, 204,1)',
              borderColor: 'rgba(144, 158, 204,1)',
              borderWidth: 1,
            },
           
        
          ],
        }
        return (
          <Grid item xs={4}>
    <Box className={styles.root}>
      <Box >
        <Line
          options={options}
          data={data}
        />
      </Box>
    </Box>
  </Grid>
);
  

};

export default LineChart;
