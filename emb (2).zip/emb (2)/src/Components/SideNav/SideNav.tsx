import reportImgUnselected from '../../Assests/img/report-unselected.svg';
import companyIconUnselected from '../../Assests/img/company-icon-unselected.svg';
import companyLogo from '../../Assests/img/embee-logo.svg';
import configureLogoUnselected from '../../Assests/img/configure-unselected.png';
import homeImageUnselected from '../../Assests/img/home-icon-unselected.svg';
import trackingDashboardUnselected from '../../Assests/img/tracking-dashboard-unselected.svg';
import inboxImageUnselected from '../../Assests/img/inbox-unselected.svg';

import reportImgSelected from '../../Assests/img/report-unselected.svg';
import companyIconSelected from '../../Assests/img/company-icon-unselected.svg';
import configureLogoSelected from '../../Assests/img/configure.png';
import homeImageSelected from '../../Assests/img/home-icon.svg';
import trackingDashboardSelected from '../../Assests/img/tracking-dashboard.svg';
import inboxImageSelected from '../../Assests/img/inbox-unselected.svg';

import { Link } from 'react-router-dom';
import { useState, useEffect } from 'react';
const styles = {
  setLogo: {
    width: '100%',
  },
  configureIcon: {
    maxHeight: '25px',
  },
};

function SideNav() {
  const [homeImage, setHomeImage] = useState(homeImageUnselected);
  const [trackingDashboard, setTrackingDashboard] = useState(
    trackingDashboardUnselected
  );
  const [companyIcon, setCompanyIconUnselected] = useState(
    companyIconUnselected
  );
  const [reportImg, setReportImg] = useState(reportImgUnselected);
  const [inboxImage, setCompanyInboxImage] = useState(inboxImageUnselected);
  const [configureLogo, setConfigureLogo] = useState(configureLogoUnselected);
  const [selectedItem, setSelectedItem] = useState('');
  const menuItems = [
    { img: homeImage, path: 'home', name: 'Home', style: {} },
    {
      img: trackingDashboard,
      path: 'tracking-dashboard',
      name: 'Tracking Dashboard',
      style: {},
    },
    { img: reportImg, path: 'report', name: 'Report', style: {} },
    { img: inboxImage, path: 'inbox', name: 'Inbox', style: {} },
    { img: companyIcon, path: 'companies', name: 'Companies', style: {} },
    {
      img: configureLogo,
      path: 'configure',
      name: 'Configure',
      style: styles.configureIcon,
    },
  ];
  const resetImages = () => {
    setSelectedItem('');
    setHomeImage(homeImageUnselected);
    setTrackingDashboard(trackingDashboardUnselected);
    setCompanyIconUnselected(companyIconUnselected);
    setReportImg(reportImgUnselected);
    setCompanyInboxImage(inboxImageUnselected);
    setConfigureLogo(configureLogoUnselected);
  };
  const selectListItem = (path: string) => {
    resetImages();
    switch (path) {
      case 'home':
        setHomeImage(homeImageSelected);
        setSelectedItem('home');
        break;

      case 'tracking-dashboard':
        setTrackingDashboard(trackingDashboardSelected);
        setSelectedItem('tracking-dashboard');
        break;

      case 'report':
        setReportImg(reportImgSelected);
        setSelectedItem('report');
        break;

      case 'inbox':
        setCompanyInboxImage(inboxImageSelected);
        setSelectedItem('inbox');
        break;

      case 'companies':
        setCompanyIconUnselected(companyIconSelected);
        setSelectedItem('companies');
        break;

      // case 'configure':
      //   setSelectedItem('configure');
      //   setConfigureLogo(configureLogoSelected);
      //   break;
    }
  };
  useEffect(()=>{
    let currentPath = window.location.href;
    if(currentPath.indexOf('home')){
      selectListItem('home')
    }
  },[])
  
  
  return (
    <>
      <ul
        className="navbar-nav bg-light sidebar bg-white accordion"
        id="accordionSidebar"
      >
        {/* <!-- Sidebar - Brand --> */}
        <div
          className="sidebar-brand d-flex align-items-center justify-content-left"
        >
        {/* <a
          className="sidebar-brand d-flex align-items-center justify-content-left"
          href="#"
        > */}
          <div className="sidebar-brand-text">
            {/* <img src="." className="logo" /> */}
            <img src={companyLogo} alt="logo" style={styles.setLogo} />
          </div>
        {/* </a> */}
        </div>

        {/* <!-- Nav Item - Dashboard --> */}
        {menuItems.map(
          (
            list: { img: string; path: string; name: string; style: any },
            index: any
          ) => (
            <li
              className="nav-item"
              key = {index}
              onClick={() => {
                selectListItem(list.path);
              }}
            >
              <Link
                className={`nav-link ${
                  list.path === selectedItem ? 'active font-weight-bold' : ''
                }`}
                to={`/main/${list.path}`}
              >
                <span className="material-symbols-outlined  menu_icon">
                  <img
                    src={`${list.img}`}
                    alt={`${list.path}`}
                    style={list.style}
                  />
                </span>
                {list.name}
              </Link>
            </li>
          )
        )}
      </ul>
    </>
  );
}

export default SideNav;
