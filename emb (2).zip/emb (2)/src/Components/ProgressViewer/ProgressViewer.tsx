function ProgressViewer(props:any){
    let progressView : any= props.barData;
    return (
        <>
            <div className="col-md-12">
              <div className="all_updated row mb-4">
                <div className="amount-box col-md-2">
                  <h5 className="total-amount_heading">{props.header}</h5>
                  <span className="total-amount">{props.total}</span>
                </div>
                <div className="total_amount-bar col-md-10 ml-auto">
                  <div className="bar-container">
                    {progressView.map((data:any,index:number)=>(
                        <div className="bar" key={index} style={{width:data.value+'%', backgroundColor: data.color,height:30}}><span>{data.value}% {data.name}</span></div>
                    ))}
                    
                    {/* <div className="bar outstanding">{props.payouts.outstanding} Outstanding</div>
                    <div className="bar overdue">{props.payouts.overdue} Overdue</div> */}
                  </div>
                </div>
              </div>
            </div>
        </>
    )
}

export default ProgressViewer;