import { ArcElement, Chart as ChartJS, Legend, Tooltip } from 'chart.js';
import React from 'react';
import { Doughnut } from 'react-chartjs-2';
import ChartDataLabels from "chartjs-plugin-datalabels";
import { Grid, Box, Typography } from '@mui/material';
import styles from './Speedometer.module.scss';

ChartJS.register(ArcElement, Tooltip, Legend, ChartDataLabels);



function SpeedOmeter(props:any) {

  const gaugeLabels = {
    id: 'gaugeLabels',
    afterDatasetsDraw(chart: any) {
      const { ctx, chartArea: { left, right } } = chart;
      const yCenter = chart.getDatasetMeta(0).data[0].y;
      ctx.font = ' 12px sans-serif';
      ctx.fillStyle = 'black';
      ctx.textAlign = 'left';
      ctx.fillText('Min', left + 35, yCenter + 20);
      ctx.font = ' 12px sans-serif';
      ctx.fillStyle = 'black';
      ctx.textAlign = 'right';
      ctx.fillText('Max', right - 30, yCenter + 20);
    }
  };
  const gaugeNeedle = {
    id: 'gaugeNeedle',
    afterDatasetsDraw(chart: any) {
      const { ctx, data } = chart;
      ctx.save();
      const xCenter = chart.getDatasetMeta(0).data[0].x;
      const yCenter = chart.getDatasetMeta(0).data[0].y;
      const outerRadius = chart.getDatasetMeta(0).data[0].outerRadius;
      const innerRadius = chart.getDatasetMeta(0).data[0].innerRadius;
      const widthSlice = (outerRadius - innerRadius) / 2;
      const radius = 8;
      const angle = Math.PI / 180;
      const needleValue = data.datasets[0].needleValue;
      const dataTotal = data.datasets[0].data.reduce((a: any, b: any) =>
        a + b, 0);
      console.log(dataTotal)
      const circumference = ((chart.getDatasetMeta(0).data[0]
        .circumference / Math.PI) / data.datasets[0].data[0]) *
        needleValue;
      ctx.translate(xCenter, yCenter);
      ctx.rotate(Math.PI * (circumference + 1.5));
      ctx.beginPath();
      ctx.strokeStyle = '#10446F';
      ctx.fillStyle = '#10446F';
      ctx.lineWidth = 1;
      ctx.moveTo(0 - 8, 0);
      ctx.lineTo(0, 0 - innerRadius - widthSlice);
      ctx.lineTo(0 + 8, 0);
      ctx.closePath();
      ctx.stroke();
      ctx.fill();
      ctx.beginPath();
      ctx.arc(0, 0, radius, 0, angle * 360, false);
      ctx.fill();
      ctx.restore();
    }
  };

  const plugins = [gaugeNeedle, gaugeLabels]
  

  return (
    <Grid item xs={4}>
      <Box className={styles.root}>
        <Box display="flex" marginBottom={4} justifyContent="space-between" px={2}>
          <Typography variant="h6" className={styles.title}>
            Average Collection Delay
          </Typography>
        </Box>
        <Box className={styles.sizes}>
          <Doughnut
            options={props.options}
            data={props.dataObj}
            plugins={plugins}
          />
        </Box>
      </Box>
    </Grid>
  )
}


export default SpeedOmeter;