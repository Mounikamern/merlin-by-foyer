import userProfile from '../../Assests/img/user_profile-img.jpg';
import searchIcon from '../../Assests/img/search-icon.svg';
import downArrow from '../../Assests/img/down-arrow.svg';
import calenderIcon from '../../Assests/img/calender.svg';
import notificationIcon from '../../Assests/img/notifications-icon.svg';

import Button from '@mui/material/Button';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';

import 'flatpickr/dist/themes/light.css';

import Flatpickr from 'react-flatpickr';

import { useState } from 'react';

import classes from './Header.module.scss';
import { getRequests } from '../../Services/api.sevice';
import { Endpoint } from '../../Utils/endpoints';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';

const styles = {
  setWidth: {
    maxWidth: '400px',
  },
  regionLabel: {
    width: '120px',
  },
};
function Header() {
  const [calenderStyle, setCalenderStyle] = useState({});
  const [region, setRegion] = useState('All Region');
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [regionEl, setregionEl] = useState<null | HTMLElement>(null);
  const navigate = useNavigate();
  const [notificationEl, setNotificationEl] = useState<null | HTMLElement>(
    null
  );

  const [date, setDate] = useState('2022-04-17');

  const open = Boolean(anchorEl);
  const openRegion = Boolean(regionEl);
  const openNotification = Boolean(notificationEl);

  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const regionMenuClick = (event: React.MouseEvent<HTMLElement>) => {
    setregionEl(event.currentTarget);
  };

  const notificationMenuClick = (event: React.MouseEvent<HTMLElement>) => {
    setNotificationEl(event.currentTarget);
  };

  const userOptions: any = ['Setting', 'Sign Out'];
  const allRegions: any = ['North', 'South', 'East', 'West'];
  const allNotifications: any = [
    'Invoice No 3456728, Company Name HCL tech 4th reminder sent',
    'Invoice No 3456728, Company Name HCL tech 4th reminder sent',
    'Invoice No 3456728, Company Name HCL tech 4th reminder sent',
    'Invoice No 3456728, Company Name HCL tech 4th reminder sent',
    'Invoice No 3456728, Company Name HCL tech 4th reminder sent',
  ];
  const handleClose = (e: any) => {
    if(e.target.innerText === 'Sign Out') {
      getRequests(Endpoint.logout).then((res) => {
        if(res.success) {
          navigate('/login');
          localStorage.clear();
        } else {
          toast.error(res.message, {
            theme: "colored"
          })
        }
      })
    }
    setAnchorEl(null);
  };
  const closeRegion = () => {
    setregionEl(null);
  };
  const closeNotification = () => {
    setNotificationEl(null);
  };

  return (
    <>
      {/* // <!-- Topbar --> */}
      <nav className="navbar navbar-expand navbar-light  topbar mb-3 mt-2 static-top">
        {/* <!-- Topbar Search --> */}
        <form className="d-none bg-white d-sm-inline-block form-inline rounded ml-md-3 mr-3  my-md-0 mw-100 navbar-search">
          <div className="input-group">
            <div className="input-group-append">
              <button className="btn search_btn " type="button">
                <span className="material-symbols-outlined">
                  <img src={searchIcon} alt="" />
                </span>
              </button>
            </div>
            <input
              type="text"
              className="form-control bg-white border-0 small"
              placeholder="Type to search any Invoice, Company..."
              aria-label="Search"
              aria-describedby="basic-addon2"
            />
          </div>
        </form>
        {/* <!-- Dropdown button -->
          <!-- delhi--> */}
        <div className="region dropdown select-wrapper mr-3">
          {/* <div className=" align-items-center input-group link-dark text-decoration-none">
            <span
              className="user_name second-dropdown"
              style={styles.regionLabel}
            >
              <strong>All Region</strong>
            </span>
            <span className="material-symbols-outlined ">
              <img src={downArrow} alt="" />
            </span>
            <ul
              className="dropdown-menu dropdown-menu-end"
              aria-labelledby="dropdownUser1"
            >
              <li className="dropdown-item">North</li>

              <li className="dropdown-item">South</li>
              <li className="dropdown-item">East</li>
              <li className="dropdown-item">West</li>
            </ul>
          </div> */}
          <Button
            id="all-region-button"
            aria-controls={openRegion ? 'all-region-menu' : undefined}
            aria-haspopup="true"
            aria-expanded={openRegion ? 'true' : undefined}
            onClick={regionMenuClick}
          >
            <div className="d-flex align-items-center d-flex link-dark text-decoration-none">
              <span
                className="user_name second-dropdown"
                style={styles.regionLabel}
              >
                <strong>{region}</strong>
              </span>
              <span className="material-symbols-outlined ">
                <img src={downArrow} alt="" />
              </span>
            </div>
          </Button>
          <Menu
            id="all-region-menu"
            aria-labelledby="all-region-button"
            anchorEl={regionEl}
            open={openRegion}
            onClose={closeRegion}
            // onClick={(element)=>{console.log(element); setRegion('')}}
            anchorOrigin={{
              vertical: 'bottom',
              horizontal: 'left',
            }}
            transformOrigin={{
              vertical: 'top',
              horizontal: 'left',
            }}
          >
            {allRegions.map((option: string, index: number) => (
              <MenuItem
                key={`${index}-region`}
                onClick={() => {
                  closeRegion();
                  setRegion(option);
                }}
              >
                <span className={classes.matCustomDropdownItem}>{option}</span>
              </MenuItem>
            ))}
          </Menu>
        </div>

        <div
          className={`${classes.setDateWrapper} date-picker `}
          style={calenderStyle}
        >
          <Flatpickr
            className={`  ${classes.setDateStyle} `}
            placeholder="Select the Date..."
            options={{
              mode: 'range',
              altInput: true,
              altFormat: 'F j, Y',
              dateFormat: 'F j, Y',
            }}
            value={date}
            onChange={() => {
              setDate(date);
            }}
            onOpen={() => {
              setCalenderStyle({
                boxShadow: '0 0 0 0.2rem rgba(78, 115, 223, 0.25)',
              });
            }}
            onClose={() => {
              setCalenderStyle({ boxShadow: 'none' });
            }}
          />
          <span className={`material-symbols-outlined`}>
            <img src={calenderIcon} alt="" />
          </span>
        </div>

        {/* <!-- Topbar Navbar --> */}

        <div className="user ml-auto pr-2 d-flex">
          {/* <div className="dropdown me-3">
              <a className="d-flex align-items-center d-flex link-dark text-decoration-none" href="#" id="dropdownUser1"
                data-bs-toggle="dropdown" aria-expanded="false">
                <img src={userProfile} alt="User Profile" className="rounded-circle me-2" width="32"
                  height="32"/>
                <span className="user_name d-flex"><strong>Sunny bharti</strong></span>
                  <span className="material-symbols-outlined "><img src={downArrow} alt="" /></span>
              </a>
              <ul className="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownUser1">
                {userOptions.map((option:string,index:number)=>(
                    <li key={index}><span className="dropdown-item">{option}</span></li>
                ))}
              </ul>
            </div> */}
          <div className="dropdown me-3">
            <Button
              id="user-account-button"
              aria-controls={open ? 'user-account-menu' : undefined}
              aria-haspopup="true"
              aria-expanded={open ? 'true' : undefined}
              onClick={handleClick}
            >
              <div className="d-flex align-items-center d-flex link-dark text-decoration-none">
                <img
                  src={userProfile}
                  alt="User Profile"
                  className={`rounded-circle me-2 ${classes.iconSpacing}`}
                  width="32"
                  height="32"
                />
                <span className="user_name d-flex">
                  <strong>Sunny bharti</strong>
                </span>
                <span className="material-symbols-outlined ">
                  <img src={downArrow} alt="" />
                </span>
              </div>
            </Button>
            <Menu
              id="user-account-menu"
              aria-labelledby="user-account-button"
              anchorEl={anchorEl}
              open={open}
              onClose={handleClose}
              anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'left',
              }}
              transformOrigin={{
                vertical: 'top',
                horizontal: 'left',
              }}
            >
              {userOptions.map((option: string, index: number) => (
                <MenuItem key={index} onClick={handleClose}>
                  <span className={classes.matCustomDropdownItem}>
                    {option}
                  </span>
                </MenuItem>
              ))}
            </Menu>
          </div>
          <div className="position-relative notification ms-3">
            <Button
              id="all-Notification-button"
              aria-controls={
                openNotification ? 'all-Notification-menu' : undefined
              }
              aria-haspopup="true"
              aria-expanded={openNotification ? 'true' : undefined}
              onClick={notificationMenuClick}
            >
              <span
                className="btn notification_bell"
                id="notificationsDropdown"
                data-bs-toggle="dropdown"
                aria-expanded="false"
              >
                <span className="material-symbols-outlined">
                  <img src={notificationIcon} alt="" />
                </span>
                <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill btn-warning">
                  4
                </span>
              </span>
            </Button>
            <Menu
              id="all-Notification-menu"
              aria-labelledby="all-Notification-button"
              anchorEl={notificationEl}
              open={openNotification}
              onClose={closeNotification}
              // onClick={(element)=>{console.log(element); setNotification('')}}
              anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'left',
              }}
              transformOrigin={{
                vertical: 'top',
                horizontal: 'left',
              }}
            >
              <div
                // className="p-4 text-muted"
                className="p-4 "
                style={styles.setWidth}
                aria-labelledby="notificationsDropdown"
              >
                <div className=" notification_outer ">
                  {allNotifications.map((option: string, index: number) => (
                    <MenuItem
                      key={`${index}-Notification`}
                      onClick={() => {
                        closeNotification();
                      }}
                    >
                      <div className="notification-box" style = {{'whiteSpace':'normal'}}>
                        <span className="mb-0">{option}</span>
                      </div>
                      {/* <span className={classes.matCustomDropdownItem}>{option}</span> */}
                    </MenuItem>
                  ))}
                </div>
              </div>
            </Menu>
          </div>

          {/* <div className="position-relative notification ms-3">
            <span
              className="btn notification_bell"
              id="notificationsDropdown"
              data-bs-toggle="dropdown"
              aria-expanded="false"
            >
              <span className="material-symbols-outlined">
                <img src={notificationIcon} alt="" />
              </span>
              <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill btn-warning">
                4
              </span>
            </span>

            <div
              className="dropdown-menu dropdown-menu-end p-4 text-muted"
              style={styles.setWidth}
              aria-labelledby="notificationsDropdown"
            >
              <div className=" notification_outer ">
                <div className="notification-box">
                  <p className="mb-0 ">
                    Invoice no 10234, Company Name - ABC Technology first
                    reminder sent
                  </p>
                </div>
                <div className="notification-box">
                  <p className="mb-0">
                    Invoice No 3456728, Company Name HCL tech 4th reminder sent
                  </p>
                </div>
                <div className="notification-box">
                  <p className="mb-0">
                    Invoice No 3456728, Company Name HCL tech 4th reminder sent
                  </p>
                </div>
                <div className="notification-box">
                  <p className="mb-0">
                    Invoice No 3456728, Company Name HCL tech 4th reminder sent
                  </p>
                </div>
                <div className="notification-box">
                  <p className="mb-0">
                    Invoice No 3456728, Company Name HCL tech 4th reminder sent
                  </p>
                </div>
                <div className="notification-box">
                  <p className="mb-0">
                    Invoice No 3456728, Company Name HCL tech 4th reminder sent
                  </p>
                </div>
              </div>
            </div>
          </div> */}
        </div>
      </nav>
      {/* <!-- End of Topbar --> */}
    </>
  );
}

export default Header;
