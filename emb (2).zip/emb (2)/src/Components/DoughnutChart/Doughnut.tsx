import React from 'react';
import { Chart as ChartJS, plugins } from 'chart.js/auto';
import { Doughnut } from 'react-chartjs-2';
import { options } from '../../Pages/Homepage/Homepage';
import { Box, Grid } from '@mui/material';
import styles from './Doughnut.module.scss'
import { BorderHorizontal } from '@mui/icons-material';
const Doughnuts = () => {
  
      
    const data={
      
        labels: [
          'Paid',
          'Outstanding',
          'Overdue'
        ],
        datasets: [
          {
            // label: 'Paid',
            data: [12,25,36],
            backgroundColor:[
              'rgba(144, 158, 204,1)',
              'rgb(144, 204, 194,1)',
              'rgba(208, 233, 179, 1)',
            ] ,
            borderColor: ['rgba(144, 158, 204,1)',
            'rgb(144, 204, 194,1)',
            'rgba(208, 233, 179, 1)'
          ],
            borderWidth: [1,20,0],
            borderHeight:[15,20,30]
          },
           
        ],
      }
           return (
            <Grid item xs={4}>
      <Box className={styles.root}>
        <Box >
          <Doughnut
            options={options}
            data={data}
          />
        </Box>
      </Box>
    </Grid>
  );
           }

export default Doughnuts;
