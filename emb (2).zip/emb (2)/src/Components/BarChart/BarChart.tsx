import { Grid, Box, Typography } from "@mui/material";
import {
  LineElement,
  Chart as ChartJS,
  Legend,
  Tooltip
} from "chart.js";
import { Bar, Line } from "react-chartjs-2";
import styles from './BarChart.module.scss';
import { Link } from "react-router-dom";

ChartJS.register(LineElement, Tooltip, Legend);

function BarChart(props:any) {

  const { data, options ,barGraphKeys } = props

  return (
    <Grid item xs={8}>
      <Box className={styles.root}>
        <Box display="flex" marginBottom={4} justifyContent="space-between" px={2}>
          <Typography variant="h5" className={styles.title}>
            Age Analysis
          </Typography>
          <Box display="flex">
            <div className={styles.legendItem}>
              <span className={styles.legendCircle} style={{ backgroundColor: 'rgba(144, 158, 204,1)' }}></span>
              <Typography variant="body1">Unadjusted Credit</Typography>
            </div>
            <div className={styles.legendItem}>
              <span className={styles.legendCircle} style={{ backgroundColor: 'rgba(144, 204, 194,1)' }}></span>
              <Typography variant="body1">Outstanding</Typography>
            </div>
            <div className={styles.legendItem}>
              <span className={styles.legendCircle} style={{ backgroundColor: 'rgba(208, 233, 179,1)' }}></span>
              {/* <Typography variant="body1">  <Link to={"/main/"}>Overdue</Link></Typography> */}
              <Typography variant="body1">  Overdue</Typography>

            </div>
          </Box>
        </Box>
        <Line
          options={props.options}
          data={props.data}
        />
      </Box>
    </Grid>
  )
}


export default BarChart;