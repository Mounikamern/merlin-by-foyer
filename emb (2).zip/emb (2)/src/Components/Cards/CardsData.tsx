export const boxData = [
    {
      title: "Upcoming",
      paragraph: "Next 7 days",
      amount: "$24135",
      dec: "20 Invoices & 4 Customers",
      sub_dec: "",
      box_style: "#d3e5f9",
      text_color: ""
    },
    {
      title: "Total Collected Amount",
      paragraph: "",
      amount: "$252300",
      dec: "10 Invoices & 3 Customers",
      sub_dec: "20% From last month",
      box_style: "#D4E5DA",
      text_color: "text-[14px] text-green-600"
    },
    {
      title: "Outstanding Amount",
      paragraph: "",
      amount: "$1215600",
      dec: "50 Invoices & 9 Customers",
      sub_dec: "5% From last month",
      box_style: "#f5f6e6",
      text_color: "text-[14px] text-red-600"
    },
    {
      title: "Overdue Amount",
      paragraph: "",
      amount: "$5243560",
      dec: "30 Invoices & 7 Customers",
      sub_dec: "10% From last month",
      box_style: "#f5e5e8",
      text_color: "text-[14px] text-green-600"
    },
    {
      title: "Unadjusted Credit",
      paragraph: "",
      amount: "$5243560",
      dec: "30 Invoices & 7 Customers",
      sub_dec: "20% From last month",
      box_style: "#def1f8",
      text_color: "text-[14px] text-green-600"
    },
  ]