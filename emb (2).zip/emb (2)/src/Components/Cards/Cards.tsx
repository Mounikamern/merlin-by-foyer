
import React from 'react'
import { Grid, Paper, Typography } from '@mui/material'

const Cards = (data:any) => {
  return (
    <div >
<Grid sx={{ flexGrow: 1 }}  container spacing={2}>
  <Grid item xs={12} >
    <Grid container direction="row" alignItems="center"justifyContent="center" spacing={4}>
       <Grid key={data.i}  item  marginTop={2} >
          <Paper sx={{ height: 150, width: 200, maxWidth: 200, padding: 2, borderRadius: 3, background: data?.box_style }}>
            <Typography style={{ fontSize: '15px', fontWeight: 600, color: '#273040', fontFamily: '"Open Sans", sans-serif', marginBottom: 1 }}> {data?.title} </Typography>
            <Typography style={{ marginTop: 2, fontSize: '12px' }}>{data?.paragraph}</Typography>
            <Typography style={{ marginTop: 1, fontSize: '24px', fontWeight: 600, color: '#273040', fontFamily: '"Open Sans", sans-serif' }}>{data?.amount}</Typography>
            <Typography style={{ marginTop: 1, fontSize: '12px', fontFamily: '"Open Sans", sans-serif' }}>{data?.dec}</Typography>
            <Typography style={{ marginTop: 3, fontSize: '12px', color: 'green', fontWeight: 550, marginBottom: 2, fontFamily: '"Open Sans", sans-serif' }}>{data?.sub_dec}</Typography>
          </Paper>
        </Grid>
    </Grid>
  </Grid>
</Grid>
</div>
    )
  }
  
  export default Cards