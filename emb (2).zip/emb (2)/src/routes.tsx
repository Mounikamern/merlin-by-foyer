import {
  Configuration,
  ForgotPassword,
  Homepage,
  Login,
  ResetPassword,
  Signup,
  TrackingDashboard,
  Report,
  Inbox,
  Companies
} from './Pages';
import Main from './Pages/Main';
import AuthGuard from './Services/Authguard';

export const config: any = [
  {
    path: '/',
    element: <Login />,
  },
  {
    path: '/login',
    element: <Login />,
    /* errorElement:<ErrorPage/>, */
  },
  {
    path: '/forgot-password',
    element: <ForgotPassword />,
  },
  {
    path: '/reset-password/:token',
    element: <ResetPassword />,
  },
  {
    path: "/signup/:token",
    element: <Signup/>  ,
    /* errorElement:<ErrorPage/>, */
  },
  {
    path: '/main',
    element: <Main />,
    children: [
      <AuthGuard
       path="/main/home" component={Homepage}/>,
      {
        path: '/main/home',
        element: <Homepage />,
      },
      {
        path: '/main/configure',
        element: <Configuration />,
      },
      {
        path: '/main/tracking-dashboard',
        element: <TrackingDashboard />,
      },
      {
        path: '/main/report',
        element: <Report />,
      },
      {
        path: '/main/inbox',
        element: <Inbox />
      },
      {
        path: '/main/companies',
        element: <Companies />
      }
      /*  {
              path:"/main/dashboard",
              async lazy() {
                let {  Dashboard } :any =  await import(
                  "./Components/Dashboard/dashboard.component"
                )
                return {
                  element: <AuthGuard Component ={Dashboard} />,
                };
              }
              
            } */
    ],
  },
];
