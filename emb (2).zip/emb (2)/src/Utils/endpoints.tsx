const API_ROOT = "https://v3cst.lightinfosys.com/api/";

export const Endpoint = {
    accessToken : () => `${API_ROOT}/users/login`,
    login: `${API_ROOT}accounts/login`,
    signup: `${API_ROOT}accounts/signup`,
    forgotPassword: `${API_ROOT}accounts/reset_password`,
    resetPassword: `${API_ROOT}accounts/set_new_password`,
    verifyResetToken: `${API_ROOT}accounts/verify_reset_token`,
    logout: `${API_ROOT}accounts/logout`
}