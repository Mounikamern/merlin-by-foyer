import React, { useEffect } from "react";
import { Route, Navigate, useNavigate  } from "react-router-dom";

const AuthGuard=(props:any)=> {
  const {Component} = props
  const navigate = useNavigate();
  useEffect(()=> {
      let login = localStorage.getItem('account_id');
      if(!login) {
          navigate('login')
      }
  });

  return (
    <div>
            <Component/>
        </div>

  )
}
export default AuthGuard;
