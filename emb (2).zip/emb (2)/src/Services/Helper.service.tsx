function Helper(){
    
    
}
/**
 *
 * @param value key and value
 * This method is used to set value in session storage
 */
export const setSessionStorage = (key: any, value: any) => {
    if (value instanceof Object) {
        sessionStorage.setItem(key, JSON.stringify(value));
    } else {
        sessionStorage.setItem(key, value);
    }
}
/**
 *
 * @returns fetched data from session storage
 * This method is used to
 */
export const getSessionStorage = (key: any) => {
    let data: any = sessionStorage.getItem(key);

    if (data) {
        try {
            let tdata = JSON.parse(data);
            return tdata;
        } catch (error) {
            return data;
        }
    }
    return '';
}
export default Helper;