import axios from 'axios';
import {setSessionStorage, getSessionStorage} from './Helper.service'
import { AxiosRequestConfig } from 'axios';
import { Endpoint } from '../Utils/endpoints';

// import createAuthRefreshInterceptor from 'axios-auth-refresh';


// axios.interceptors.request.use(
//   async(request:any) => {
//     // log a message before any HTTP request is sent
//     console.log('Request was sent', request);
//     const token = getSessionStorage('accessToken');
//     // const location = window.location.href;

//     if (!token) {
//         const newAccessToken = await refreshAccessToken();
//         setSessionStorage('accessToken', newAccessToken);
//     }
//     request.headers['Authorization'] = `Bearer ${token}`;

//     return request;
//   },
//   (err:any) => {
//     console.log(err);
//   }
// );

// interface RetryQueueItem {
//     resolve: (value?: any) => void;
//     reject: (error?: any) => void;
//     config: AxiosRequestConfig;
// }

// const refreshAndRetryQueue: RetryQueueItem[] = [];

// let isRefreshing = false;

// axios.interceptors.response.use(
//     (response: any) => response,
//     async (error: any) => {
//         const originalRequest: AxiosRequestConfig = error.config;
        
//         if (error.response && error.response.status === 401) {
//             if (!isRefreshing) {
//                 isRefreshing = true;
//                 try {
//                 // Refresh the access token
//                     const newAccessToken = await refreshAccessToken();
//                     setSessionStorage('accessToken', newAccessToken)
//                     // Update the request headers with the new access token
//                     error.config.headers['Authorization'] = `Bearer ${newAccessToken}`;
                    
//                     // Retry all requests in the queue with the new token
//                     refreshAndRetryQueue.forEach(({ config, resolve, reject }) => {
//                         axios
//                         .request(config)
//                         .then((response: any) => resolve(response))
//                         .catch((err: any) => reject(err));
//                     });

//                     // Clear the queue
//                     refreshAndRetryQueue.length = 0;

//                     // Retry the original request
//                     return axios(originalRequest);
//                 } catch (refreshError) {
//                     // Handle token refresh error
//                     // You can clear all storage and redirect the user to the login page
//                     throw refreshError;
//                 } finally {
//                     isRefreshing = false;
//                 }
//             }

//         // Add the original request to the queue
//         return new Promise((resolve, reject) => {
//             refreshAndRetryQueue.push({ config: originalRequest, resolve, reject });
//         });
//         }

//         // Return a Promise rejection if the status code is not 401
//         return Promise.reject(error);
//     }
// );
const customFetch = async (url:string, { data, ...customConfig }:any) => {
  const config = {
    url,
    ...customConfig,
    headers: {
      ...customConfig.headers,
    },
    data,
  };

  try {
    const response = await axios(config);
    const data = response.data;

    if (data.success) {
      return {
        data: data.data,
        success: true,
      };
    }
    throw new Error(data.message);
  } catch (err:any) {
    return {
      message: err.response.data ? err.response.data.message : err.message,
      success: false,
    };
  }
};

const refreshAccessToken = () => {
    // Generate and sign an access token
    // Return the access token
    return postRequests(Endpoint.accessToken(),{})
};
  
//   const generateRefreshToken = () => {
//     // Generate and sign a refresh token
//     // Return the refresh token
//     return postRequests(Endpoint.accessToken(),{})
//   };
export const getRequests = (url:string, config = {}) => {
  return customFetch(url, {
    method: 'GET',
    ...config,
  });
};
export const postRequests = (url:string, config:any) => {
    return customFetch(url, {
        method: 'POST',
        ...config,
      });
};

export const putRequests = (url:string, config:any) => {
    return customFetch(url, {
        method: 'PUT',
        ...config,
      });
};

export const patchRequests = (url:string, config:any) => {
    return customFetch(url, {
        method: 'PUT',
        ...config,
      });
};



// const refreshAuthLogic = (failedRequest) =>
//   axios
//     .post('https://www.example.com/auth/token/refresh')
//     .then((tokenRefreshResponse) => {
//       localStorage.setItem('token', tokenRefreshResponse.data.token);
//       failedRequest.response.config.headers['Authorization'] =
//         'Bearer ' + tokenRefreshResponse.data.token;
//       return Promise.resolve();
//     });

// Instantiate the interceptor
// createAuthRefreshInterceptor(axios, refreshAuthLogic);



// axios.interceptors.response.use(
//     (response) => {
//       return response;
//     },
//     async (error) => {
//       if (error.response.status === 401) {
//         let token = await refreshAccessToken();
//         axios.defaults.headers.common['Authorization'] = 'Bearer ' + token;
//       }
//     }
//   );